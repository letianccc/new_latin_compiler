

void main() {
    int a = 1;
    int b = a;
    int c = 2, d = b, e;
    e = 3;
    printf("target 1: %d\n", a);
    printf("target 1: %d\n", b);
    printf("target 1: %d\n", d);
    printf("target 2: %d\n", c);
    printf("target 3: %d\n", e);
    getchar();
}
