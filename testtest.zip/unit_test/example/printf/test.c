


void main() {
    double a = 1.5, b = 2.5, c = 3.5;
    printf("value: %f, %f, %f\n", 1.5, 2.5, 3.5);
    printf("value: %f, %f, %f\n", a, b, c);
    printf("value: %f, %f, %f\n", 1.5, b, c);
    printf("value: %f, %f, %f\n", a, 2.5, c);
    printf("value: %f, %f, %f\n", a, b, 3.5);
    getchar();
}
