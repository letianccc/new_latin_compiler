


void main() {
    int a = 50000;
    short b = 20000;
    int c = (int)b + a;
    printf("target 70000: %d\n", c);
    getchar();
}
