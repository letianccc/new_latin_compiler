



void main() {
	int i = 0;
	while (i < 5) {
		printf("hello %d\n", i);
		i = i + 1;
	}

	double d = 0;
	while (d < 5) {
		printf("hello %f\n", d);
		d = d + 1;
	}

	short s = 0;
	while (s < 5) {
		printf("hello %d\n", s);
		s = s + 1;
	}

	getchar();
}
