

void main() {
	int i = 0;
	++i;
	printf("target 1: %d\n", i);
	printf("target 1: %d\n", +i);
	getchar();
}
