from unit_test.lexer_ import test_lexer
from unit_test.parser_ import test_parser
from unit_test.gen import test_gen, test_as
from unit_test.execute import test_exec

test_lexer()
test_parser()
# test_gen()
# test_as()
test_exec()
