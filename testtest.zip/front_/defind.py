


class Defind(object):
    """docstring for Defind."""

    def __init__(self, kind, destination, source1, source2=None):
        super(Defind, self).__init__()
        self.kind = kind
        self.dst = destination
        self.src1 = source1
        self.src2 = source2
