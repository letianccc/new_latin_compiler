

#include<stdio.h>


void main() {

	for (int i = 0, j = 0; i<8, j<5; i++, j++) {
		printf("hello\n");


	}

	getchar();
}
