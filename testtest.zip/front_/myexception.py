

DuplicateDefinitionMessage = "同一作用域中不可重复定义"


class DuplicateDefinitionException(Exception):
    ...
