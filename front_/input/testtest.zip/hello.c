

#include<stdio.h>

void f() {
	return 0;
}
void main() {

	int b;
	b = f();
	getchar();
}
